function changeStatus() {
  const trackingCode = document.getElementById("trackingCode").value.trim();
  const errorMessageElement = document.getElementById("errorMessage");
  const statusImg = document.getElementById("statusImg");
  const statusText = document.getElementById("status");

  // Check if a tracking code is provided
  if (trackingCode !== "") {
    errorMessageElement.textContent = ""; // Clear error message

    const images = ["package_received.png", "in_transit.png", "package_held.png"];
    let currentStatusIndex = 0;

    // Display loading spinner while fetching data
    statusImg.src = "spinner.gif";
    statusText.innerText = "Status: Fetching data...";

    const intervalId = setInterval(() => {
      if (currentStatusIndex < images.length) {
        statusImg.src = images[currentStatusIndex];
        switch (currentStatusIndex) {
          case 0:
            statusText.innerText = "Status: Package Received";
            break;
          case 1:
            statusText.innerText = "Status: In Transit";
            break;
          case 2:
            statusText.innerText = "Status: Package Held";
            break;
        }
        currentStatusIndex++;
      } else {
        clearInterval(intervalId);
        statusImg.src = "";
        statusText.innerText = "";
      }
    }, 3000);
  } else {
    // If no tracking code is provided, display error message
    statusImg.src = "";
    statusText.innerText = "";
    errorMessageElement.textContent = "Please enter a tracking code.";
  }
}
